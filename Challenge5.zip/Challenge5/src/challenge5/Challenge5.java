/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package challenge5;

import java.util.Scanner;

/**
 *
 * @author 6172449
 */
public class Challenge5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner keyboard = new Scanner(System.in);
         String answer;
        do 
        {
           
            System.out.println("Enter a word: ");
            String word = keyboard.next();
            String changedWord = changeXY(word);
            System.out.println("The new word is " + changedWord);
            
            System.out.println("Do you want to enter another word?");
            answer = keyboard.next();
            
        } while (answer.equalsIgnoreCase("Yes"));
        
    
        
    }
    
    public static String changeXY(String aWord) 
    {
        if(aWord.length() == 0)
        {
            return " ";
        }
        else if(aWord.charAt(0) == 'x') 
        {
            
            return ('y' + changeXY(aWord.substring(1)));
        }
        else 
        {
            char newChar;
            newChar = aWord.charAt(0);
            return newChar + changeXY(aWord.substring(1));
        }
    }
    
}
